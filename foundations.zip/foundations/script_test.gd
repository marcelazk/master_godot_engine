@tool
extends EditorScript


# Called when the script is executed (using File -> Run in Script Editor).
func _run() -> void:
	var character_name: String = "Legolas"
	var character_age: int = 2931
	var character_health: float = 100.0
	var character_is_alive: bool = true

	print(character_name)
	print(type_string(typeof(character_name)))
	print(character_age)
	print(type_string(typeof(character_age)))
	print(character_health)
	print(type_string(typeof(character_health)))
	print(character_is_alive)
	print(type_string(typeof(character_is_alive)))
