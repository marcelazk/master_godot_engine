extends Node2D

@onready var plane: Sprite2D = %Plane
@onready var helicopter: Sprite2D = $Helicopter
@onready var eating_sound: AudioStreamPlayer = $EatingSound

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	#plane_follow_heli(delta)
	#plane_follow_mouse(delta)
	#plane_fly_round(delta)
	#plane_control(delta)
	plane_transform(delta)
	
	if Input.is_action_just_pressed("ui_accept"):
		eating_sound.play()
		#plane.global_position = Vector2(350,150)
		
func plane_follow_mouse(delta: float) -> void:
	plane.look_at(get_global_mouse_position())
	plane.move_local_x(200.0 * delta)
	
func plane_follow_heli(delta: float) -> void:
	var dir: Vector2 = plane.position.direction_to(helicopter.position)
	plane.look_at(helicopter.position)
	plane.translate(dir * 60.0 * delta)
	
	helicopter.position.y += 60.0 * delta
	
func plane_fly_round(delta: float) -> void:
	plane.rotate(1.0 * delta)
	plane.move_local_x(50.0 * delta)
	
func plane_control(delta: float) -> void:
	plane.move_local_x(60.0 * delta)
	if Input.is_action_pressed("ui_left"):
		plane.rotate(-1.5 * delta)
	if Input.is_action_pressed("ui_right"):
		plane.rotate(1.5 * delta)

func plane_transform(delta: float) -> void:
	# using plane at a 30ª rotation
	# similar to plane.move_local_x
	plane.position += plane.transform.x * 60.0 * delta
